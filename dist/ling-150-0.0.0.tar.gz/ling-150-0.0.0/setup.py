from setuptools import setup

setup(
    name='ling-150',
    version='',
    packages=['conclass-webpage'],
    url='http://conclasswebpage.com',
    license='',
    author='Sydney Bess',
    author_email='sydneybess@email.arizona.edu',
    description='Ling 150 project'
)
